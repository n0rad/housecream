

FCKLang.imgmapBtn			= 'Insert/Edit Image Map';
FCKLang.imgmapBtnRemove			= 'Remove map';
FCKLang.imgmapDlgTitle		= 'Image Map Editor';
FCKLang.imgmapDlgName		= 'ImageMapEditor';

FCKLang.msgImageNotSelected = 'You must select an image before using this dialog' ;

FCKLang.imgmapNoLabel = 'No labeling' ;
FCKLang.imgmapLabelNumber = 'Label with numbers' ;
FCKLang.imgmapLabelAlt = 'Label with alt text' ;
FCKLang.imgmapLabelHref = 'Label with href' ;
FCKLang.imgmapLabelTitle = 'Label with title' ;
FCKLang.imgmapLabelCoords = 'Label with coords' ;
FCKLang.imgmapLabelZoom = 'Zoom' ;

FCKLang.imgmapMap = 'Map' ;
FCKLang.imgmapMapName = 'Map name' ;
FCKLang.imgmapMapAreas = 'Image Map Areas' ;

FCKLang.imgmapPointer = 'Pointer' ;
FCKLang.imgmapRectangle = 'Rectangle' ;
FCKLang.imgmapCircle = 'Circle' ;
FCKLang.imgmapPolygon = 'Polygon' ;
FCKLang.imgmapDeleteArea = 'Delete selected area' ;

