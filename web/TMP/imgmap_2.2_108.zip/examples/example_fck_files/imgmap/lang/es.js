
FCKLang.imgmapBtn			= 'Insertar/Editar zonas interactivas';
FCKLang.imgmapBtnRemove			= 'Quitar el mapa';
FCKLang.imgmapDlgTitle		= 'Editor de zonas interactivas';
FCKLang.imgmapDlgName		= 'ImageMapEditor';

FCKLang.msgImageNotSelected = 'Debes elegir una imagen antes de usar este diálogo' ;

FCKLang.imgmapNoLabel = 'Sin etiquetas' ;
FCKLang.imgmapLabelNumber = 'Etiquetas con números' ;
FCKLang.imgmapLabelAlt = 'Etiquetas con el texto alternativo' ;
FCKLang.imgmapLabelHref = 'Etiquetas con la URL' ;
FCKLang.imgmapLabelTitle = 'Etiquetas con el título' ;
FCKLang.imgmapLabelCoords = 'Etiquetas con las coordenadas' ;
FCKLang.imgmapLabelZoom = 'Zoom' ;

FCKLang.imgmapMap = 'Mapa' ;
FCKLang.imgmapMapName = 'Nombre del mapa' ;
FCKLang.imgmapMapAreas = 'Zonas interactivas' ;

FCKLang.imgmapPointer = 'Puntero' ;
FCKLang.imgmapRectangle = 'Rectángulo' ;
FCKLang.imgmapCircle = 'Círculo' ;
FCKLang.imgmapPolygon = 'Polígono' ;
FCKLang.imgmapDeleteArea = 'Eliminar zona';
