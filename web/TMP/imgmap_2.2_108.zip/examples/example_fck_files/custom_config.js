FCKConfig.Plugins.Add('imgmap','en,es,de','../../');

FCKConfig.ToolbarSets["Default"][FCKConfig.ToolbarSets["Default"].length] = new Array('imgmapPopup');


