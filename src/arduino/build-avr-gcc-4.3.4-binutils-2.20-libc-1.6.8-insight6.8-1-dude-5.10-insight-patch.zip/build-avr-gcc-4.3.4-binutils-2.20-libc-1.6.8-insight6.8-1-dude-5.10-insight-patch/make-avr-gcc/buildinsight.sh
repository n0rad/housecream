#!/bin/bash

# ARM GNU development tools install script
# $Id: buildarm.sh,v 1.25 2007/02/02 04:23:08 rmoffitt Exp $

# Copyright (C) 2003-2004 Rod Moffitt rod@rod.info http://rod.info
# 
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

# run the script as is to get a list of the files necessary to build,
# takes optionally three arguments, the location of the source files,
# where to install and build the tools and the path where to output a
# log file

# start of configuration, edit these defaults to suit your environment, or
# simply override them via the command line - you will need write
# permission to $prefix (make sure it's empty or non-existent!)

# location of source tarballs
archive=${PWD}

#
#Save base/build dir
#
base=${PWD}
patchdir="$base/patches"

#
# Get package versions 
#
source ${base}/package-versions
#

# GNU tools will be installed under this directory
prefix=/usr/local/avr

# build log file - see this if any errors occur
buildlog=/tmp/buildavr-insight.log

# end of configuration

# what are we building for?
target=avr

sourcefiles="${insighttar}"



function buildandinstall
{
  # path to the newly installed binutils is needed to build GCC
   PATH=$prefix/bin:$PATH

   mkdir -p $prefix/source $prefix/build

   cd $prefix/source

   echo "($0) installing insight source"
   tar xvjf $archive/${insighttar}
   cerror "insight source installation failed"

   cd ${insightbase}

   echo "($0) patching Insight/GDB source"
#
for file in $patchdir/${insightbase}/*; do
    echo "Patching with $file"
    patch -p0 < $file
    cerror "gcc patching failed"
done
#
   mkdir -p ../../build/${insightbase}
   cd ../../build/${insightbase}

   echo "($0) configuring insight"
   ../../source/${insightbase}/configure -v --quiet --prefix=$prefix \
      --target=${target}  \
      --with-gnu-ld --with-gnu-as --disable-werror CFLAGS="-Wno-format-security "
   cerror "insight configuration failed"

   echo "($0) building insight"
   make all install clean
   cerror "insight build failed"

 
   cecho "\n"
   cecho "${cyan}installation of ${target} GNU tools complete\n"
   cecho "${cyan}add ${GREEN}$prefix/bin${cyan} to your path to use the ${target} GNU tools\n"
   cecho "${cyan}you might want to run the following to save disk space:\n"
   cecho "\n"
   cecho "${green}rm -rf $prefix/source $prefix/build\n"
}

# color definitions
RED='\e[1;31m'
green='\e[0;32m'
GREEN='\e[1;32m'
cyan='\e[0;36m'
yellow='\e[0;33m'
NC='\e[0m' # no color

function cecho
{
   echo -ne "($green$0$NC) $1$NC"
}

function cerror
{
   if [ $? -ne 0 ];
   then
      cecho "$RED$1 $GREEN($?)$NC\n"
      exit
   fi
}

function ask
{
   cecho "$@ [y/n] "
   read ans

   case "$ans" in
      y*|Y*) return 0 ;;
      *) return 1 ;;
   esac
}

# source command line overrides

until [ -z "$1" ];
do
   eval "$1"
   shift
done

cecho "${cyan}about to build and install ${target} GNU development tools using\n"
cecho "${cyan}the following settings (override via the command line):\n"
cecho "\n"
cecho "   ${yellow}archive=${archive} $cyan(location of source tarballs)\n"
cecho "   ${yellow}prefix=${prefix} $cyan(installation prefix/directory)\n"
cecho "   ${yellow}buildlog=${buildlog} $cyan(build log)\n"
cecho "\n"
ask "${cyan}proceed?";

if [ "$?" -eq 1 ]
then
   exit
fi

# check on target directory

if [ -d $prefix ];
then
   cecho "\n"
   ask "${RED}$prefix already exists, continue?";

   if [ "$?" -eq 1 ]
   then
      exit
   fi
fi

mkdir -p $prefix 2> /dev/null

if [ ! -w $prefix ];
then
   cecho "\n"
   cecho "${RED}failed! to create install directory $prefix\n";
   exit
fi

# check for required files

missingfiles=;

for file in $sourcefiles;
do
   if [ ! -f $archive/$file ];
   then
      missingfiles="${missingfiles} $file";
   fi
done

if [ -n "$missingfiles" ];
then
   cecho "\n"
   cecho "${RED}error! required source file(s):\n";
   cecho "\n"

   for file in $missingfiles;
   do
      cecho "   ${yellow}$file\n"
   done

   cecho "\n"
   cecho "${cyan}were missing - download them to $archive first\n";
   exit
fi

buildandinstall 2>&1 | tee $buildlog

exit

