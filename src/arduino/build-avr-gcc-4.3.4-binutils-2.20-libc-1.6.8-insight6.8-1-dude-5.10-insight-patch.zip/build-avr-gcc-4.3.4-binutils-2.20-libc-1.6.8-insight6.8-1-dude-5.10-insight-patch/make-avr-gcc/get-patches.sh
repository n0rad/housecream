#!/bin/bash

#
#Save base/build dir
#
base=${PWD}
patchdir="$base/patches"


#
# Get package versions 
#
source ${base}/package-versions
#

mkdir -p ${patchdir}

#############################################################
# Binutils
#############################################################
cd ${base}
cd ${patchdir}
mkdir ${binutilsbase}
cd ${binutilsbase}
rm -fr *
#
# Get binutils patches
#
#wget -c  --user-agent=MyBrowser http://www.freebsd.org/cgi/cvsweb.cgi/~checkout~/ports/devel/avr-binutils/files/patch-aa
#
# Rename to our patchname
#
#mv patch-aa binutils-patch-aa.diff
#

#
# New way of getting patches , get the full tarball
#
wget -c  --user-agent=MyBrowser http://www.freebsd.org/cgi/cvsweb.cgi/ports/devel/avr-binutils/files/files.tar.gz?tarball=1
tar xvzf *
cd files

mv * ..
cd ..
rm -fr files*
cd ${base}


#############################################################
# GCC
#############################################################
cd ${base}
cd ${patchdir}
mkdir ${gccbase}
cd ${gccbase}
rm -fr *


#
# New way of getting patches , get the full tarball
#
wget -c  --user-agent=MyBrowser http://www.freebsd.org/cgi/cvsweb.cgi/~checkout~/ports/devel/avr-gcc/files/files.tar.gz?tarball=1
tar xvzf *
cd files

mv * ..
cd ..
rm -fr files*
cd ${base}

#############################################################
# Insight/GDB
#############################################################
cd ${base}
cd ${patchdir}
mkdir ${insightbase}
cd ${insightbase}
rm -fr *


#
# New way of getting patches , get the full tarball
#
wget -c  --user-agent=MyBrowser http://www.freebsd.org/cgi/cvsweb.cgi/~checkout~/ports/devel/avr-gdb/files/files.tar.gz?tarball=1
tar xvzf *
cd files

mv * ..
cd ..
rm -fr files*
cd ${base}

#############################################################
# Avrdude - empty for now
#############################################################

#############################################################
# Avarice - empty for now
#############################################################


