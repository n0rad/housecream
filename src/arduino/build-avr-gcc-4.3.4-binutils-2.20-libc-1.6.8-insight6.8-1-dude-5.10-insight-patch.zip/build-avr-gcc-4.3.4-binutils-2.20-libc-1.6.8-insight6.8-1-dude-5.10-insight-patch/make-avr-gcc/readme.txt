Description: Ubuntu 8.10 avr-gcc toolchain  based on the below script from AvrFreaks.
 build-avr-gcc-4.3.4-binutils-2.20-libc-1.6.8-insight6.8-1-dude-5.10-insight-patch  
 
 @04-jun-2010
 switched to insight 6.8-1
 
 @09-mar-2010
 Switched to gcc-4.3.4 , Jörg did update the FreeBSD repos so it should perform like the WinAVR 2010 release.
 If you need the builtins.h , copy it from the scriptdir to this dir /usr/local/avr/avr/include/avr
 hopefully it will install automatic in the next version of avr-libc.
 
 @08-mar-2010
 Switched to binutils 2.20

 @26-Jan-2010
 Avrdude 5.10 released , so build using that. All other , unchanged.

 @16-Jan-2010
 Avrdude 5.9 released , so build using that , instead of the 2 below patches.
 All other , unchanged
 
 @06-jan-2010
 Also apply this avrdude patch http://www.mail-archive.com/avrdude-dev@nongnu.org/msg01922.html
 to fix bug #27507. 
 Note... This patch isn't accepted upstream , but it is confirmed to fix a dragon isp programming crash


 @17-dec-2009   
 Rebuild avrdude 5.8 with the PDI patch from here
 http://www.avrfreaks.net/index.php?name=PNphpBB2&file=viewtopic&p=637539#637539     



 This package will install avr-gcc-4.3.4 with binutils 2.20 and avr-libc 1.6.8.
 Plus  avr-insight 6.8  , avarice-2.10 and avrdude-5.10
 It will install in /usr/local/avr , and i honestly dont know what happens if this directory exists on install.
   
 A big thank you goes to the avr-gcc team , and Joerg Wunsch for making the FREE-BSD patches i use in the linux build,
 and for being a driving force in making/maintaining avr-libc.
 
 Thank you to Eric Weddington , for maintaining WinAVR , though it seems like WinAVR-2010 will be the last one.
  
 Also thanx to Ruud Vlaaming (FemtoOS) author , i snipped the GMP/MPFR GCC Inline trick from his toolchain.
  
 Start by reading this thread http://www.avrfreaks.net/index.php?name=PNphpBB2&file=viewtopic&t=42631
 Or at least the first post.
  
 The following devices are supported : 
 A snip from the command : avr-gcc --target-help
  
Known MCU names:
  avr1 avr2 avr25 avr3 avr31 avr35 avr4 avr5 avr51 avr6 avrxmega1
  avrxmega2 avrxmega3 avrxmega4 avrxmega5 avrxmega6 avrxmega7 at90s1200
  attiny11 attiny12 attiny15 attiny28 at90s2313 at90s2323 at90s2333
  at90s2343 attiny22 attiny26 at90s4414 at90s4433 at90s4434 at90s8515
  at90c8534 at90s8535 attiny13 attiny13a attiny2313 attiny2313a attiny24
  attiny24a attiny4313 attiny44 attiny44a attiny84 attiny25 attiny45
  attiny85 attiny261 attiny261a attiny461 attiny861 attiny861a attiny87
  attiny43u attiny48 attiny88 at86rf401 ata6289 at43usb355 at76c711
  atmega103 at43usb320 attiny167 attiny327 at90usb82 at90usb162 atmega8u2
  atmega16u2 atmega32u2 atmega8 atmega48 atmega48a atmega48p atmega88
  atmega88a atmega88p atmega88pa atmega8515 atmega8535 atmega8hva
  atmega4hvd atmega8hvd atmega8c1 atmega8m1 at90pwm1 at90pwm2 at90pwm2b
  at90pwm3 at90pwm3b at90pwm81 atmega16 atmega16a atmega161 atmega162
  atmega163 atmega164a atmega164p atmega165 atmega165p atmega168
  atmega168a atmega168p atmega169 atmega169a atmega169p atmega169pa
  atmega16hva atmega16hvb atmega16c1 atmega32 atmega323 atmega324a
  atmega324p atmega324pa atmega325 atmega325p atmega3250 atmega3250p
  atmega328 atmega328p atmega329 atmega329p atmega329pa atmega3290
  atmega3290p atmega32hvb atmega406 atmega64 atmega640 atmega644
  atmega644a atmega644p atmega644pa atmega645 atmega645a atmega645p
  atmega649 atmega649p atmega649a atmega6450 atmega6450a atmega6450p
  atmega6490 atmega6490a atmega6490p atmega64hve atmega16hva atmega16hva2
  atmega16hvb atmega32hvb at90can32 at90can64 at90pwm216 at90pwm316
  atmega32c1 atmega64c1 atmega16m1 atmega32m1 atmega64m1 atmega16u4
  atmega32u4 atmega32u6 at90usb646 at90usb647 at90scr100 at94k atmega128
  atmega1280 atmega1281 atmega1284p atmega128rfa1 at90can128 at90usb1286
  at90usb1287 m3000f m3000s m3001b atmega2560 atmega2561 atxmega16a4
  atxmega16d4 atxmega32d4 atxmega32a4 atxmega64a3 atxmega64d3 atxmega64a1
  atxmega128a3 atxmega128d3 atxmega192a3 atxmega192d3 atxmega256a3
  atxmega256a3b atxmega256d3 atxmega128a1

  
  
 /Bingo
