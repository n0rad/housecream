#!/bin/bash

#
#Save base/build dir
#
base=${PWD}

#
# Get package versions 
#
source ${base}/package-versions
#

#
# Get GDB Insight
#
wget -c  ftp://sourceware.org/pub/insight/releases/${insighttar}
#
# Get avarice
#
wget -c  http://downloads.sourceforge.net/avarice/${avaricetar}
#
# Get avrdude
#
wget -c  http://download.savannah.gnu.org/releases/avrdude/${avrdudetar}
wget -c  http://download.savannah.gnu.org/releases/avrdude/avrdude-doc-${avrdudever}.pdf
#
# Get Binutils
#
#wget -c  ftp://ftp.dkuug.dk/pub/gnu/ftp/gnu/binutils/binutils-2.19.1.tar.bz2
wget -c  ftp://ftp.dkuug.dk/pub/gnu/ftp/gnu/binutils/${binutilstar}

#
# Get avr-libc
#
#
wget -c  http://download.savannah.gnu.org/releases/avr-libc/avr-libc-user-manual-${avrlibcver}.pdf.bz2
wget -c  http://download.savannah.gnu.org/releases/avr-libc/${avrlibctar}

#
# Get GMP
#
#wget -c http://ftp.sunet.se/pub/gnu/gmp/gmp-4.2.4.tar.bz2
wget -c http://ftp.sunet.se/pub/gnu/gmp/${gmptar}
#
# Get MPFR
#
#wget -c http://www.mpfr.org/mpfr-current/mpfr-2.4.1.tar.bz2
#wget -c http://www.mpfr.org/mpfr-current/mpfr-2.4.1.tar.bz2
# Don't use "current dir" they keep changing the files , use url's like below
wget -c http://www.mpfr.org/mpfr-2.4.1/${mpfrtar}
#
#Get GCC
#
#wget -c  ftp://ftp.dkuug.dk/pub/gnu/ftp/gnu/gcc/gcc-4.3.2/gcc-4.3.2.tar.bz2
wget -c  ftp://ftp.dkuug.dk/pub/gnu/ftp/gnu/gcc/${gcccore}/${gcccoretar}
#
# Done
#

